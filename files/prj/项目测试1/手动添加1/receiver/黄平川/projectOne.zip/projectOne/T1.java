package projectOne;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.io.IOException;

public class T1 {

	public static void main(String[] args) throws IOException
	{
		final BigDecimal THICKNESS = new BigDecimal(0.0001);
		final BigDecimal LIGHTYEAR = new BigDecimal(9460730472580800L);
		BigDecimal folded = THICKNESS;
		for(int i=0;i<27;i++)
		{
			folded = doubleUp(folded);
		}
		if(folded.compareTo(BigDecimal.valueOf(8848))>=0)
		{
			System.out.println("Folded Paper is higher");
		}
		else System.out.println("Summit is higher");
		
		folded = THICKNESS;
		for(int i=0;i<72;i++)
		{
			folded = doubleUp(folded);
		}
		
		System.out.println("equals to "+folded.divide(LIGHTYEAR,RoundingMode.HALF_UP).setScale(0,RoundingMode.HALF_UP)+" Light Year");
	}
	
	public static BigDecimal doubleUp(BigDecimal n)
	{
		return n.multiply(BigDecimal.valueOf(2));
	}

}
